If the application is configured "confLoadmode = local" in tmc.config, then make the changes in TMC_data.json, template.json files. Else directly change in appsettings.json file. 
______________________*****__________________________________


TMC_data.json
Add the below configs: (change the Generic service (NICE URL))
	
  "tmc.conf.SlotBookingCertfile": "",
  "tmc.conf.SlotBookingCertPassword": "",
  
  "tmc.conf.GenericService": "http://localhost:8731/Generic_Connector/GenericService/",
  "tmc.conf.GenericCertfile": "",
  "tmc.conf.GenericCertPassword": ""

  
-------------------************--------------
template.json 

Remove the below config keys: 

	//NICE Integration Report ServiceConfigurations//
    "GenericServiceUserName": "administrator",
    "GenericServicePassword": "Password",
    "GenericServiceServerURL": "http://localhost:8731/Generic_Connector/GenericService/",
    "GenericServiceServerName": "localhost",
	
	//TMACSiebelRelease Path this JSON will strore Batch IIS file path//
    "TMACSiebelReleasePath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\TMACSiebelRelease\\TMACSiebelRelease.json",
	
	//IVR Ops Control Module Configurations//
    "IvrOpsParameters": "",

    // Mapping of VDN and Hotlines to be shown in the reports for Analysis Count Graph//
    "VDNList": [  ],
    "HotlineList": " ",
	
	//Name of the Chat Servers used in Chat Configurations//
    "ChatServerNames": "Chat Server 1,Chat Server 2",

    //IP of each Chat Server Name used in Chat Configurations//
    "ChatServerIp": "http://localhost:65500/rconfig_tchat/",
	
	// Transaction Category list to get category dropdown in Transaction Limit Management module//
    "TransactionCategory": "",
	
	//Locations for branch details//
    "BranchDetailsLocation": "",

    // Personalize Ivr module drop down values for "Next Action" to determine whether digital option will be automatically offered to the caller, or IVR will provide caller the option to self-select to proceed with digital option.//
    "NextActionPersonalizeIvr": "",

    // Personalize Ivr module drop down values for "Sub Action" to determine whether the call will be terminated or IVR will proceed with BAU call flow after SMS is triggered //
    "SubActionPersonalizeIvr": "",

    // Functionality Names for IvrPhraseConfiguration//
    "IvrPhraseConfigurationFunctionality": "",

    //IVR Autho Flag Config Module Configurations//
    "IvrAuthoFlagParameters": "",
	
	// Slot Booking Rest API URL //
    "SlotBookingAPIUrl": [ "tmc.conf.SlotBookingAPIUrl" ],

    // SlotBooking service certificate folder//
    "SlotBookingCertificateFolder": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\CertificateFiles",
	
	/////////////////////////////////////////////////////////////////////// Security Administrator Role ID  Configurations /////////////////////////////////////////////////////////////////////////////////////
    //Security Administrator Role ID//
    "SecurityAdministratorRoleID": 2,

    //Base Address configured in the RPA Upload Service exe.Config//
    "RPAServiceEndpoint": "http://localhost:40404/TRPAUploaderAPI/api/Post",

    //Set to true if certificate is to be binded to the RPA request(https) when synchronizing with other servers//
    "IsRPACertificateBindingRequired": true,

    /////////////////////////////////////////////////////////////////////// End of Security Administrator Role ID  Configurations /////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////////// Start of IVR Public Key Config Configurations /////////////////////////////////////////////////////////////////////////////////////
    // IPs of multiple MPP servers of public key config //
    "PublicKeyConfigMPPIps": "tmc.conf.PublicKeyConfigMPPIps",
    //Public key config MPP server file path//
    "PublicKeyConfigMPPPath": "tmc.conf.PublicKeyConfigMPPPath",
    //Public key config local file path //
    "PublicKeyConfigLocalPath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\PublicKeyConfig\\",

    /////////////////////////////////////////////////////////////////////// End of IVR Public Key Config Configurations /////////////////////////////////////////////////////////////////////////////////////

	"WorkFlowsFreeTextPath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\WorkFlowsFreeText\\",
    "PhoneNumbers": "90946527,90994433",
    "WakeUpCallStatus": "",
    "WaveFileUploadPathWakeUpCall": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\WakeupCallPath\\",
    "WaveFileURLWakeUpCall": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\WakeupCallPath\\",
	
	////////////////////////////////// Start of IRAS Web admin Phase 2 modules configuration /////////////////////////////////////////
						 
    //Path to upload Contingency Wavefiles//
    "ContingencyFileUploadPath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\ContingencyFileUploadPath\\",
				 
    //IP to browse Wavefiles in OCM//
    "ContingencyWaveFileURL": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\ContingencyFileUploadPath\\",
	
	// Contingency Call flow name list//
    "ContingencyCallflows": "Emergency Callflow,System Maintenance Callflow,Bypass IVR Callflow",

    //Contingency Call flow name list used for wave file upload//
    "ContingencyCallflowsforWaveFileUpload": "Emergency Callflow,System Maintenance Callflow,Bypass IVR Callflow",

    //Hotline ID of the Super admin//
    "SuperAdminHotlineID": "3001,3002",

    //comma separated Call flow name list that should not display for super admin(other hotline's)//
    "RestrictCallflowforSuperAdmin": "Bypass IVR Callflow",

    ////////////////////////////////// End of IRAS Web admin Phase 2 modules configuration /////////////////////////////////////////
 
    /////////////////////////////////////////////SmartDialer Configuration /////////////////////////////////////////////////////////
    //Soap url of the smart dialer//
    "SmartDialerAPIURL": "tmc.conf.SmartDialerAPIURL",
    //Soap url request of smart dialer credential for username//
    "SmartDialerUserName": "tmc.conf.SmartDialerUserName",
    //Soap url request of smart dialer credential for username//
    "SmartDialerPassword": "tmc.conf.SmartDialerPassword",
    ////////////////////////////////////////////End of SmartDialer Configuration ////////////////////////////////////////////////////
    "POMSettings": {
      //////////////////////////////////////////////////////////////////Start of Outbound Keys/////////////////////////////////
      //Value should be either TeleSales/Collections//
      "AutoDialer": "Telesales",
      //Whether to display contact list or not in DncBulkUpload module //
      "DisplayContactList": true,
      //Please also change in POMPurgingUtility.js if anything is changed in AttributeTypes//
      "AttributeTypes": "Expiry_Date,NRIC,CAMP_ID",
      //Collection keys for attributes filter fields in POMPurgingUtility.js//
      "AttributesForCollections": "ID,CIN,Location_ID",
      //Collection keys for attributes filter condtion in POMPurgingUtility.js//
      "ConditionTypes": "Equals,Greater than,Less than,Greater than or Equal to,Less than or Equal to,Not Equal to",
      //POM manual upload CSV/Text file path//
      "csvFilePath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\CsvFiles\\Manual_Upload\\",
      // CSV/Text upload URL to download files//
      "CsvAddr": "tmc.conf.CsvAddr",
      //to store manual upload temp file during preprocessing//
      "CsvTempFileLocation": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\CsvFiles\\Newfolder\\",
      //to check phone number during preprocessing in POM manual upload//
      "prefixNumbers": "^(65|065)",
      //JSON file to store compaign links //
      "POMCampaignLinksConnectorpath": "E:\\pomcampaignconnector.json",
      //Type of the file, for collections 'txt' else 'csv'//
      "ManualFileType": "csv",
      //Path of JAR file//
      "ManualJARFile": "",
      //Country of AutoDialer either SG or TH or MY//
      "AdCountry": "SG",
      //POM purgin utility for filed to direct pruge with attribute//
      "FieldsToDirectPurge": [ "nric", "Expiry_Date", "CAMP_ID" ],
      "DirectPurge": "",
      "PurgePageNumber": 0,
      //Differeciate org. with respect to country and stream//
      "OrganizationName": "SG_TS_SIT",
      //POM server TimeZone//
      "TimeZone": "GMT+05:30",
      //POM date format//
      "PomDateFormat": "dd/MM/yyyy",
      //Organization name to get list of campaign //
      "CampaignSearchValue": "SG_TS",
      // each page has max count in it, for purge contactbatch api call//
      "PurgePerPageLimit": 100,
						  
      // contact list filter attribute//
								  
      "ContactListFilter": "_manual",
      "VDNContactListMapping": "",
      "VDNTeamNameMapping": "",
      "CallBackExpiryDays": "",
      "maskInternationalNumbers": "",
      "IDDCountryCodeList": "",
      "DialCode": "",
      "PurgeAttributeKeyToFilter": "CAMP_ID",
      "CallbackReason": "",
      "PurgeDateTimeFormat": "yyyy-MM-dd HH:mm:ss",
      //SSH details//
      "sshHostName": "10.133.146.11",
      "sshPort": 22,
      "sshUserName": "ashwath",
      "sshPrivateKeyFile": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\sshprivatekey.ppk",
      "sshRemotePath": "/sshpath/",
      //During FTP to upload to POM server using pscp tool path//
      "toolName": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\pscp.exe",
      //POM select purging limit//
      "PurgePageSize": 1,
      //contact list name to give for save contact list method//
      "ContactListNameToSave": "SG_TS_Callback_1"
      /////////////////////End of Outbound pages keys/////////////////////
																	 
    }
	

---------------****----------------

update config key: 

	"AuditTraildllList": "OCM.Model,OCM.Model.Custom,TSocialMediaAPIConnector,Tetherfi.Custom.TMACUtilsDataAccess",


Add the below keys: (Change the Generic service (NICE URL))


	// Custom is disabled/enabled (0/1) //
    "IsCustomEnabled": 1,

    "CustomSettings": {
      //////////////////////////////////////////////////////////////////Start of OCM.Custom Keys/////////////////////////////////
      //Hotline ID of the Super admin//
      "SuperAdminHotlineID": "3001,3002",

      // Contingency Call flow name list//
      "ContingencyCallflows": [ "Emergency Callflow", "System Maintenance Callflow", "Bypass IVR Callflow" ],

      //Contingency Call flow name list used for wave file upload//
      "ContingencyCallflowsforWaveFileUpload": [ "Emergency Callflow", "System Maintenance Callflow", "Bypass IVR Callflow" ],

      //comma separated Call flow name list that should not display for super admin(other hotline's)//
      "RestrictCallflowforSuperAdmin": "Bypass IVR Callflow",

      //IP to browse Wavefiles in OCM//
      "ContingencyWaveFileURL": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\ContingencyFileUploadPath\\",

      //Path to upload Contingency Wavefiles//
      "ContingencyFileUploadPath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\ContingencyFileUploadPath\\",

      "WakeUpCallStatus": "",			   

      "WaveFileURLWakeUpCall": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\WakeupCallPath\\",

      "WaveFileUploadPathWakeUpCall": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\WakeupCallPath\\",

      //Name of the Chat Servers used in Chat Configurations//
      "ChatServerNames": "Chat Server 1,Chat Server 2",

      //IP of each Chat Server Name used in Chat Configurations//
      "ChatServerIp": "http://sit.tetherfi.com:65500/rconfig_tchat/,http://10.133.146.65:39500/rconfig_tchat/",

      //TMACSiebelRelease Path this JSON will strore Batch IIS file path//
      "TMACSiebelReleasePath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\TMACSiebelRelease\\TMACSiebelRelease.json",

      //Base Address configured in the RPA Upload Service exe.Config//
      "RPAServiceEndpoint": "http://localhost:40404/TRPAUploaderAPI/api/Post",

      //Set to true if certificate is to be binded to the RPA request(https) when synchronizing with other servers//
      "IsRPACertificateBindingRequired": true,

      // Mapping of VDN and Hotlines to be shown in the reports for Analysis Count Graph//
      "VDNList": [  ],
      "HotlineList": " ",

      //IVR Ops Control Module Configurations//
      "IvrOpsParameters": "",

      // Transaction Category list to get category dropdown in Transaction Limit Management module//
      "TransactionCategory": "",

      //Locations for branch details//
      "BranchDetailsLocation": "",

      // Personalize Ivr module drop down values for "Next Action" to determine whether digital option will be automatically offered to the caller, or IVR will provide caller the option to self-select to proceed with digital option.//
      "NextActionPersonalizeIvr": "",

      // Personalize Ivr module drop down values for "Sub Action" to determine whether the call will be terminated or IVR will proceed with BAU call flow after SMS is triggered //
      "SubActionPersonalizeIvr": "",

      // Functionality Names for IvrPhraseConfiguration//
      "IvrPhraseConfigurationFunctionality": "",

      //IVR Autho Flag Config Module Configurations//
      "IvrAuthoFlagParameters": "",

      "WorkFlowsFreeTextPath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\WorkFlowsFreeText\\",
      "PhoneNumbers": "90946527,90994433",

      /////////////////////////////////////////////SmartDialer Configuration /////////////////////////////////////////////////////////
      //Smart Dialer upload teemplate path for download
      "SmartDialerTemplatePath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\SDUploadFileTemplate v5.xlsm",
      ////////////////////////////////////////////End of SmartDialer Configuration ////////////////////////////////////////////////////

      //////////////////////////////////////////// Start of IVR Public Key Config Configurations ///////////////////////////////////
      // IPs of multiple MPP servers of public key config //
      "PublicKeyConfigMPPIps": "tmc.conf.PublicKeyConfigMPPIps",
      //Public key config MPP server file path//
      "PublicKeyConfigMPPPath": "tmc.conf.PublicKeyConfigMPPPath",
      //Public key config local file path //
      "PublicKeyConfigLocalPath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\PublicKeyConfig\\",

      //////////////////////////////////////////// End of IVR Public Key Config Configurations ///////////////////////////////////////

      //NICE Integration Report ServiceConfigurations//
      "GenericServiceUserName": "administrator",
      "GenericServicePassword": "Password",
      "GenericServiceServerURL": "http://localhost:8731/Generic_Connector/GenericService/",
      "GenericServiceServerName": "localhost",

      /////////////////////////////////////////////////////////////////////// Security Administrator Role ID  Configurations /////////////////////////////////////////////////////////////////////////////////////
      //Security Administrator Role ID//
      "SecurityAdministratorRoleID": 2,

      /////////////////////////////////////////////////////////////////////// End of Security Administrator Role ID  Configurations /////////////////////////////////////////////////////////////////////////////////////

      "POMSettings": {
        //////////////////////////////////////////////////////////////////Start of Outbound Keys/////////////////////////////////
        //Value should be either TeleSales/Collections//
        "AutoDialer": "Telesales",
        //Whether to display contact list or not in DncBulkUpload module //
        "DisplayContactList": true,
        //Please also change in POMPurgingUtility.js if anything is changed in AttributeTypes//
        "AttributeTypes": "Expiry_Date,NRIC,CAMP_ID",
        //Collection keys for attributes filter fields in POMPurgingUtility.js//
        "AttributesForCollections": "ID,CIN,Location_ID",
        //Collection keys for attributes filter condtion in POMPurgingUtility.js//
        "ConditionTypes": "Equals,Greater than,Less than,Greater than or Equal to,Less than or Equal to,Not Equal to",
        //POM manual upload CSV/Text file path//
        "csvFilePath": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\CsvFiles\\",
        // CSV/Text upload URL to download files//
        "CsvAddr": "tmc.conf.CsvAddr",
        //to store manual upload temp file during preprocessing//
        "CsvTempFileLocation": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\CsvFiles\\TempFolder\\",
        //to check phone number during preprocessing in POM manual upload//
        "prefixNumbers": "^(65|065)",
        //JSON file to store compaign links //
        "POMCampaignLinksConnectorpath": "E:\\pomcampaignconnector.json",
        //Type of the file, for collections 'txt' else 'csv'//
        "ManualFileType": "csv",
        //Path of JAR file//
        "ManualJARFile": "",
        //Country of AutoDialer either SG or TH or MY//
        "AdCountry": "SG",
        //POM purgin utility for filed to direct pruge with attribute//
        "FieldsToDirectPurge": [ "nric", "Expiry_Date", "CAMP_ID" ],
        "DirectPurge": "",
        "PurgePageNumber": 0,
        //Differeciate org. with respect to country and stream//
        "OrganizationName": "SG_TS_SIT",
        //POM server TimeZone//
        "TimeZone": "GMT+05:30",
        //POM date format//
        "PomDateFormat": "dd/MM/yyyy",
        //Organization name to get list of campaign //
        "CampaignSearchValue": "SG_TS",
        // each page has max count in it, for purge contactbatch api call//
        "PurgePerPageLimit": 100,

        // contact list filter attribute//
        "ContactListFilter": "_manual",
        "VDNContactListMapping": "",
        "VDNTeamNameMapping": "",
        "CallBackExpiryDays": "",
        "maskInternationalNumbers": "",
        "IDDCountryCodeList": "",
        "DialCode": "",
        "PurgeAttributeKeyToFilter": "CAMP_ID",
        "CallbackReason": "",
        "PurgeDateTimeFormat": "yyyy-MM-dd HH:mm:ss",
        //SSH details//
        "sshHostName": "10.133.146.11",
        "sshPort": 22,
        "sshUserName": "ashwath",
        "sshPrivateKeyFile": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\sshprivatekey.ppk",
        "sshRemotePath": "/sshpath/",
        //During FTP to upload to POM server using pscp tool path//
        "toolName": "tmc.conf.TetherfiAppPath\\tmc.conf.ProductName\\pscp.exe",
        //POM select purging limit//
        "PurgePageSize": 1,
        //contact list name to give for save contact list method//
        "ContactListNameToSave": "SG_TS_Callback_1"
        /////////////////////End of Outbound pages keys/////////////////////
      }
      //////////////////////////////////////////////////////////////////End of OCM.Custom Keys/////////////////////////////////
    }
	
	
	
In template.json file : connectors section. add below URL's. 
	
	{
      "serviceType": "SlotBooking",
      "uniqueKey": "SlotBooking",
      "serviceName": "PrimaryService",
      "addresses": [
        {
          "key": "rest",
          "value": "tmc.conf.SlotBookingAPIUrl"
        },
        {
          "key": "cert-file",
          "value": ""
        },
        {
          "key": "cert-password",
          "value": ""
        }
      ]
    },
	{
	"serviceType": "GenericService",
    "uniqueKey": "GenericService",
    "serviceName": "PrimaryService",
    "addresses": [
      {
        "key": "wcf",
        "value": "tmc.conf.GenericService"
      },
      {
        "key": "cert-file",
        "value": "tmc.conf.GenericCertfile"
      },
      {
        "key": "cert-password",
        "value": "tmc.conf.GenericCertPassword"
      }
    ]						
    }

